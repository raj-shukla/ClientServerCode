import os
import sys
import time
file = open('file', 'r')
string = file.readline()
for index in range(0, 29*100*100):
    print(string)
 
