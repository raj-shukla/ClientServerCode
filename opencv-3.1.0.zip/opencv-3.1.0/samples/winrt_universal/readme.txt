Building OpenCV WinRT Universal Samples
=======================================

Samples are created to run against x86 architecture OpenCV binaries.

Please follow the instructions in "platforms/winrt/readme.txt" to generate and build OpenCV for WinRT.